#!/bin/bash

image_base_name="freeipa-server"
image_description="FreeIPA Server AMI"
image_version="1.4.0"

s3_bucket="stet-images"
s3_folder="sabr-devops-lab-images"

echo "Baking the image ${image_base_name}-${image_version} ..."
vagrant up
sleep 30
vagrant halt
mkdir bake
cd bake
echo "Exporting the VM ${image_base_name} ..."
vagrant package --base ${image_base_name}  --output ${image_base_name}.box --vagrantfile ../Vagrantfile
gunzip -S .box ${image_base_name}.box
tar xf ${image_base_name} && rm -rf ${image_base_name}
echo "Uploading the VM to s3://${s3_bucket}/${s3_folder}/ ..."
aws s3 cp box-*.vmdk s3://${s3_bucket}/${s3_folder}/${image_base_name}-${image_version}
echo "[{\"Description\":\"${image_description}\",\"Format\": \"VMDK\",\"UserBucket\":{\"S3Bucket\":\"${s3_bucket}\",\"S3Key\": \"${s3_folder}/${image_base_name}-${image_version}\"}}]" > jm.json
aws ec2 import-image --description "${image_description}" --disk-containers "file://jm.json" | jq -r .ImportTaskId > jm.taskid
jm_id=$(cat jm.taskid)
status=$(aws ec2 describe-import-image-tasks --import-task-ids $jm_id | jq -r .ImportImageTasks[0].Status)
while [ "$status" != "completed" ]
do
   echo "AMI task still importing, sleeping"
   sleep 60
   status=$(aws ec2 describe-import-image-tasks --import-task-ids $jm_id | jq -r .ImportImageTasks[0].Status)
done
jm_ami=$(aws ec2 describe-import-image-tasks --import-task-ids $jm_id | jq -r .ImportImageTasks[0].ImageId)
aws ec2 create-tags --resources $jm_ami --tags Key=Name,Value="${image_base_name}-${image_version}"
aws ec2 create-tags --resources $jm_ami --tags Key=project,Value="sabr_devops_lab"
aws s3 rm --recursive s3://${s3_bucket}/${s3_folder}/${image_base_name}-${image_version}

rm -rf *

vagrant destroy -f