#!/bin/bash

yum module enable idm:DL1 -y
yum distro-sync -y
yum module install idm:DL1/dns -y



