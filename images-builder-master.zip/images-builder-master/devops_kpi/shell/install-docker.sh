#!/bin/bash

sudo dnf config-manager --add-repo=https://download.docker.com/linux/centos/docker-ce.repo
sudo dnf makecache
sudo dnf -y install --nobest docker-ce
# sudo docker version
# # get latest docker compose released tag
COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep 'tag_name' | cut -d\" -f4)

# # Install docker-compose
sh -c "curl -L https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-`uname -s`-`uname -m` > /usr/local/bin/docker-compose"
chmod +x /usr/local/bin/docker-compose
# sudo sh -c "curl -L https://raw.githubusercontent.com/docker/compose/${COMPOSE_VERSION}/contrib/completion/bash/docker-compose > /etc/bash_completion.d/docker-compose"

sudo yum install -y git
sudo mkdir -p /etc/systemd/system/docker.service.d
sudo touch /etc/systemd/system/docker.service.d/proxy.conf
sudo echo "[Service]" >> /etc/systemd/system/docker.service.d/proxy.conf
sudo echo "Environment='HTTP_PROXY=http://172.16.40.4:8080/'" >> /etc/systemd/system/docker.service.d/proxy.conf
sudo echo "Environment='HTTPS_PROXY=http://172.16.40.4:8080/'" >> /etc/systemd/system/docker.service.d/proxy.conf

sudo systemctl daemon-reload 
sudo systemctl restart docker.service

cp /tmp/docker_compose/docker-compose.yml /home/vagrant/

cd /home/vagrant

sudo docker compose pull

rm -rf /hom/vagrant/docker-compose.yml

# install freeipa-client
yum install -y freeipa-client

firewall-cmd --permanent --add-service={http,https} --permanent
firewall-cmd --permanent --add-port 6001/tcp
firewall-cmd --permanent --add-port 6004/tcp
firewall-cmd --reload
