#!/bin/bash

image_base_name="generic"
image_description="STET Devops Toolchain Generic Image"
image_version="2.2.0"

jenkins_docker_image_name="stet/jenkins-lts:0.0.3"
nexus_docker_image_name="sonatype/nexus3:3.58.1" 
gitlab_docker_image_name="gitlab/gitlab-ce:15.11.0-ce.0"
vault_docker_image_name="hashicorp/vault:1.14"
grafana_docker_image_name="grafana/grafana:10.0.1"
influxdb_docker_image_name="influxdb:2.7.1"

s3_bucket="stet-images"
s3_folder="sabr-devops-lab-images"

echo "Baking the image ${image_base_name}-${image_version} ..."
docker save ${jenkins_docker_image_name} > data/stet_jenkins_lts.tar
docker save ${nexus_docker_image_name} > data/nexus.tar
docker save ${gitlab_docker_image_name} > data/gitlab.tar
docker save ${vault_docker_image_name} > data/vault.tar
docker save ${grafana_docker_image_name} > data/grafana.tar
docker save ${influxdb_docker_image_name} > data/influxdb.tar
vagrant up
sleep 30
vagrant halt
rm -rf data/*.tar
mkdir bake
cd bake
echo "Exporting the VM ${image_base_name} ..."
vagrant package --base ${image_base_name}  --output ${image_base_name}.box --vagrantfile ../Vagrantfile
gunzip -S .box ${image_base_name}.box
tar xf ${image_base_name} && rm -rf ${image_base_name}
echo "Uploading the VM to s3://${s3_bucket}/${s3_folder}/ ..."
aws s3 cp box-*.vmdk s3://${s3_bucket}/${s3_folder}/${image_base_name}-${image_version}
echo "[{\"Description\":\"${image_description}\",\"Format\": \"VMDK\",\"UserBucket\":{\"S3Bucket\":\"${s3_bucket}\",\"S3Key\": \"${s3_folder}/${image_base_name}-${image_version}\"}}]" > jm.json
aws ec2 import-image --description "${image_description}" --disk-containers "file://jm.json" | jq -r .ImportTaskId > jm.taskid
jm_id=$(cat jm.taskid)
status=$(aws ec2 describe-import-image-tasks --import-task-ids $jm_id | jq -r .ImportImageTasks[0].Status)
while [ "$status" != "completed" ]
do
   echo "AMI task still importing, sleeping"
   sleep 60
   status=$(aws ec2 describe-import-image-tasks --import-task-ids $jm_id | jq -r .ImportImageTasks[0].Status)
done
jm_ami=$(aws ec2 describe-import-image-tasks --import-task-ids $jm_id | jq -r .ImportImageTasks[0].ImageId)
aws ec2 create-tags --resources $jm_ami --tags Key=Name,Value="${image_base_name}-${image_version}"
aws ec2 create-tags --resources $jm_ami --tags Key=project,Value="sabr_devops_lab"
aws s3 rm --recursive s3://${s3_bucket}/${s3_folder}/${image_base_name}-${image_version}

rm -rf *

vagrant destroy -f