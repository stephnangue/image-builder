#!/bin/bash

proxy=http://172.16.40.4:8080

# install git
sudo yum install -y git

# install epel-release
yum -y install epel-release
yum -y update

# install jq
yum -y install jq
jq -Version

# install docker
yum -y remove docker docker-latest docker-engine docker-client docker-common docker-client-latest docker-logrotate docker-latest-logrotate
yum check-update
yum upgrade
yum-config-manager --add-repo=https://download.docker.com/linux/centos/docker-ce.repo
yum -y install docker-ce --nobest --allowerasing
systemctl start docker
systemctl status docker
systemctl enable docker
docker --version
setfacl --modify user:vagrant:rw /var/run/docker.sock

docker load < /tmp/data/stet_jenkins_lts.tar
docker load < /tmp/data/nexus.tar
docker load < /tmp/data/gitlab.tar
docker load < /tmp/data/vault.tar
docker load < /tmp/data/grafana.tar
docker load < /tmp/data/influxdb.tar
docker images

yum -y install java-11-openjdk-devel

# remove epel-release
yum -y remove epel-release
yum -y update

#install Ansible Vault Module
pip3 install --trusted-host files.pythonhosted.org --trusted-host pypi.org --trusted-host pypi.python.org --proxy http://172.16.40.4:8080 --default-timeout=100 ansible-modules-hashivault

# install freeipa-client
yum install -y freeipa-client
