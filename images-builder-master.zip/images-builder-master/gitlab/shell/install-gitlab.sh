#!/bin/bash

#install python-gitlab
pip3 install --trusted-host files.pythonhosted.org --trusted-host pypi.org --trusted-host pypi.python.org --proxy http://172.16.40.4:8080 --default-timeout=100 python-gitlab
#install request
pip3 install --trusted-host files.pythonhosted.org --trusted-host pypi.org --trusted-host pypi.python.org --proxy http://172.16.40.4:8080 --default-timeout=100 requests

yum -y install curl vim policycoreutils python3-policycoreutils

wget https://packages.gitlab.com/install/repositories/gitlab/gitlab-ce/script.rpm.sh
chmod +x script.rpm.sh
./script.rpm.sh
rm -f script.rpm.sh

yum -y install gitlab-ce

# install freeipa-client
yum install -y freeipa-client

firewall-cmd --permanent --add-service={http,https} --permanent
firewall-cmd --reload

#############
