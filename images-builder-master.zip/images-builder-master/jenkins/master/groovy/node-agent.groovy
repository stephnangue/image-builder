import jenkins.model.*
import com.cloudbees.plugins.credentials.*
import com.cloudbees.plugins.credentials.common.*
import com.cloudbees.plugins.credentials.domains.*
import com.cloudbees.plugins.credentials.impl.*
import com.cloudbees.jenkins.plugins.sshcredentials.impl.*
import hudson.plugins.sshslaves.*

println "--> creating SSH credentials" 

domain = Domain.global()
store = Jenkins.instance.getExtensionList('com.cloudbees.plugins.credentials.SystemCredentialsProvider')[0].getStore()

String passPhrase = new File('/var/lib/jenkins/.ssh/sabr.private.passphrase').getText().trim()

privateKeySource = new BasicSSHUserPrivateKey.FileOnMasterPrivateKeySource('/var/lib/jenkins/.ssh/sabr.private')

slavesPrivateKey = new BasicSSHUserPrivateKey(
CredentialsScope.GLOBAL,
"jenkins-worker-key-id",
"vagrant",
privateKeySource,
passPhrase,
"Vagrant user SSH key"
)

store.addCredentials(domain, slavesPrivateKey)

println "--> SSH credentials created" 