#!/bin/bash

jenkins_plugin_manager_version=2.12.9
jenkins_war_file=/usr/share/java/jenkins.war
jenkins_plugins_dir=/var/lib/jenkins/plugins
proxyHost=172.16.40.4
proxyPort=8080

# install git
sudo yum install -y git

wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat-stable/jenkins.repo
rpm --import https://pkg.jenkins.io/redhat/jenkins.io-2023.key

yum upgrade
yum -y install java-11-openjdk-devel
yum -y install jenkins

mkdir -p /var/lib/jenkins/init.groovy.d
cp /tmp/groovy_scripts/*.groovy /var/lib/jenkins/init.groovy.d/
chown -R jenkins:jenkins /var/lib/jenkins/init.groovy.d
cp /tmp/config/jenkins /etc/sysconfig/jenkins
systemctl enable jenkins
systemctl start jenkins
systemctl status jenkins

mkdir /var/lib/jenkins/.ssh
cp /home/vagrant/.ssh/sabr.private /var/lib/jenkins/.ssh/
cp /home/vagrant/.ssh/sabr.private.passphrase /var/lib/jenkins/.ssh/
chown -R jenkins:jenkins /var/lib/jenkins/.ssh

java -Dhttp.proxyPort=${proxyPort} -Dhttp.proxyHost=${proxyHost} -Dhttps.proxyPort=${proxyPort} -Dhttps.proxyHost=${proxyHost} -jar /tmp/plugin/jenkins-plugin-manager-${jenkins_plugin_manager_version}.jar --war ${jenkins_war_file} --plugin-file /tmp/plugin/plugins.txt -d ${jenkins_plugins_dir} --verbose
systemctl restart jenkins
systemctl status jenkins

# install freeipa-client
yum install -y freeipa-client

#open the firewall
firewall-cmd --zone=public --permanent --add-service=http
firewall-cmd --zone=public --permanent --add-service=https
firewall-cmd --permanent --add-port 8080/tcp
firewall-cmd --reload





