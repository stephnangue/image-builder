#!/bin/bash

nexus_version="3.47.1-01"

yum install java-1.8.0-openjdk.x86_64 -y

cd /opt
wget -O nexus.tar.gz https://download.sonatype.com/nexus/3/nexus-${nexus_version}-unix.tar.gz
tar -xvf nexus.tar.gz && rm -f nexus.tar.gz
mv nexus-3* nexus

useradd --home-dir /opt/nexus --no-create-home --system nexus
cat <<EOF > /opt/nexus/bin/nexus.rc
run_as_user="nexus"
EOF
chown -R nexus:nexus /opt/nexus
chown -R nexus:nexus /opt/sonatype-work

ln -s /opt/nexus/bin/nexus /etc/init.d/nexus
cp /tmp/nexus_config/nexus.service /etc/systemd/system/nexus.service

systemctl daemon-reload
systemctl enable nexus.service
systemctl start nexus.service
systemctl status nexus

# install freeipa-client
yum install -y freeipa-client

#open the firewall
firewall-cmd --zone=public --permanent --add-service=http
firewall-cmd --zone=public --permanent --add-service=https
firewall-cmd --permanent --add-port 8081/tcp
firewall-cmd --reload