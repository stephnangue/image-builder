
remove user vagrant and his home dir 
remove user vboxadd and his home dir
Also groups
uninstall vbox guest additions
desynchronise the folders