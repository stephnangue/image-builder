#!/bin/bash

echo "Installing OpenSCAP scanner ..."
yum -y install openscap-scanner scap-security-guide
ls -lrt /usr/share/xml/scap/ssg/content/
# display description for each content
oscap info /usr/share/xml/scap/ssg/content/ssg-centos8-ds-1.2.xml


# xccdf : specify [xccdf] module
# ⇒ available modules : info, xccdf, oval, ds, cpe, cvss, cve, cvrf
# [--profile] : specify profile
# ⇒ available profiles are on the result you run [oscap info] command above
# [--results] : output file
# [--report] : output HTML report
# [--fetch-remote-resources] : download the latest data
echo "Scanning the system for compliance with PCI-DSS ..."
oscap xccdf eval \
--profile xccdf_org.ssgproject.content_profile_pci-dss \
--results ssg-centos8-ds-1.2.xml \
--report ssg-centos8-ds-1.2.html \
--fetch-remote-resources \
/usr/share/xml/scap/ssg/content/ssg-centos8-ds-1.2.xml


# make sure the [Result ID] is in the result output
oscap info ssg-centos8-ds-1.2.xml | grep "Result ID"

# generate remediation script
# [--fix-type] : specify fix type : default is Bash
# ⇒ available type : bash, ansible, puppet, anaconda, ignition, kubernetes, blueprint
# [--output] : specify output script file
# [--result-id] : specify [Result ID]
echo "Generating the remediation script ..."
oscap xccdf generate fix \
--fix-type bash \
--output ssg-centos8-ds-1.2-remediation.sh \
--result-id xccdf_org.open-scap_testresult_xccdf_org.ssgproject.content_profile_pci-dss   \
ssg-centos8-ds-1.2.xml

# run remediation script
echo "Running the remediation script ..."
source ssg-centos8-ds-1.2-remediation.sh

rm -rf *

