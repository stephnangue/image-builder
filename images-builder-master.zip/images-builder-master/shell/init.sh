#!/bin/bash

cat << EOF >> /etc/yum.conf
proxy=http://172.16.40.4:8080
EOF
PROXY_URL="http://172.16.40.4:8080/"
export http_proxy="$PROXY_URL"
export https_proxy="$PROXY_URL"
export ftp_proxy="$PROXY_URL"
export HTTP_PROXY="$PROXY_URL"
export HTTPS_PROXY="$PROXY_URL"
export FTP_PROXY="$PROXY_URL"
export LC_ALL="en_US.UTF-8"
export LC_CTYPE="en_US.UTF-8"
export | grep proxy

cat << EOF >> /home/vagrant/.bashrc

export LC_ALL="en_US.UTF-8"
export LC_CTYPE="en_US.UTF-8"
EOF

cp /tmp/certificates/*.crt /etc/pki/ca-trust/source/anchors/
update-ca-trust

cat /tmp/certificates/devops-lab-public-key >> /home/vagrant/.ssh/authorized_keys

cat <<EOF > /home/vagrant/.ssh/config
host 10.7*
  user vagrant
  IdentityFile  /home/vagrant/.ssh/sabr.private
EOF
chown vagrant:vagrant /home/vagrant/.ssh/config

sed -i 's/mirrorlist/#mirrorlist/g' /etc/yum.repos.d/CentOS-*
sed -i 's|#baseurl=http://mirror.centos.org|baseurl=http://vault.centos.org|g' /etc/yum.repos.d/CentOS-*
yum-config-manager --disable epel
yum check-update

# install ansible
yum install -y python39
alternatives --set python3 /usr/bin/python3.9
alternatives --set python /usr/bin/python3.9
#sudo pip3 install --trusted-host files.pythonhosted.org --trusted-host pypi.org --trusted-host pypi.python.org --proxy http://172.16.40.4:8080 --default-timeout=100 --upgrade --ignore-installed pip setuptools
sudo pip3 install --trusted-host files.pythonhosted.org --trusted-host pypi.org --trusted-host pypi.python.org --proxy http://172.16.40.4:8080 --default-timeout=100  ansible -v




