#!/bin/bash

yum-config-manager --add-repo https://rpm.releases.hashicorp.com/RHEL/hashicorp.repo
yum -y install vault

cp /tmp/vault_config/vault.service /etc/systemd/system/vault.service
cp /tmp/vault_config/vault_config.hcl /etc/vault.d/vault_config.hcl

systemctl enable vault.service
systemctl start vault.service
systemctl status vault.service

#install Ansible Vault Module
pip3 install --trusted-host files.pythonhosted.org --trusted-host pypi.org --trusted-host pypi.python.org --proxy http://172.16.40.4:8080 --default-timeout=100 ansible-modules-hashivault

# install freeipa-client
yum install -y freeipa-client

firewall-cmd --zone=public --permanent --add-service=http
firewall-cmd --zone=public --permanent --add-service=https
firewall-cmd --permanent --add-port 8200/tcp
firewall-cmd --reload